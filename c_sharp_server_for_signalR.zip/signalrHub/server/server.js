const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("@microsoft/signalr");

const app = express();
app.use(cors()); 

const port = 5000;


const server = http.createServer(app);
class ChatHub extends Server {
    constructor() {
        super();
        this.on("connection", (connection) => {
            console.log("Client connected:", connection.connectionId);

           
            connection.on("SendMessage", (user, message) => {
                console.log(`Received from ${user}: ${message}`);
                this.clients.all.send("ReceiveMessage", user, message); // Broadcast message
            });

            connection.onclose(() => console.log("Client disconnected"));
        });
    }
}

const chatHub = new ChatHub();
chatHub.attach(server, "/chatHub");

server.listen(port, () => {
    console.log(`✅ SignalR Server running at: http://localhost:${port}/chatHub`);
});
